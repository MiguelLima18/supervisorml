const video = document.getElementById('video');
const startButton = document.getElementById('startButton');

startButton.addEventListener('click', async () => {
    try {
        // Solicita acceso a la cámara
        const stream = await navigator.mediaDevices.getUserMedia({ video: true });
        video.srcObject = stream;
    } catch (err) {
        if (err.name === 'NotAllowedError') {
            alert("Permiso denegado. Por favor, permite el acceso a la cámara.");
        } else if (err.name === 'NotFoundError') {
            alert("No se encontró ninguna cámara.");
        } else {
            console.error("Error al acceder a la cámara: ", err);
            alert("Ocurrió un error al intentar acceder a la cámara.");
        }
    }
});
